
# Related Work

Time-series traffic prediction has been explored with models like SARIMA, Prophet, and LSTM. SARIMA is effective for seasonal data, while Prophet is well-suited for data with irregular seasonality and holidays. Studies show that hybrid models often improve traffic forecasting accuracy.
