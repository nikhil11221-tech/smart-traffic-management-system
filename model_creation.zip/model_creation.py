
# model_creation.py

from statsmodels.tsa.statespace.sarimax import SARIMAX
from prophet import Prophet

def create_sarima_model(data):
    model = SARIMAX(data, order=(1, 1, 1), seasonal_order=(1, 1, 1, 12))
    sarima_result = model.fit(disp=False)
    return sarima_result

def create_prophet_model(data):
    prophet_data = data.reset_index().rename(columns={'Date': 'ds', 'Traffic': 'y'})
    model = Prophet()
    model.fit(prophet_data)
    return model
