
# Traffic Prediction Project

This project aims to predict traffic patterns using SARIMA and Prophet models on time-series data.

## Installation

1. Clone the repository.
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

## Files

- `related_work.md`: Related research and background.
- `data_preprocessing.py`: Preprocesses and cleans the traffic dataset.
- `visualization.py`: Provides exploratory visualizations.
- `model_creation.py`: Builds and trains SARIMA and Prophet models.
- `evaluation.py`: Evaluates model performance.
- `main.py`: Executes the complete pipeline.

## Usage

Run the entire pipeline:
```bash
python src/main.py
```

## Results

See the `notebooks/EDA.ipynb` for visualizations and data analysis.
