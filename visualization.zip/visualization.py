
# visualization.py

import matplotlib.pyplot as plt
import seaborn as sns

def plot_traffic_data(data):
    plt.figure(figsize=(12, 6))
    plt.plot(data, label="Traffic Volume")
    plt.title("Traffic Volume Over Time")
    plt.xlabel("Date")
    plt.ylabel("Volume")
    plt.legend()
    plt.show()

def plot_seasonal_decomposition(data, result):
    result.plot()
    plt.show()
