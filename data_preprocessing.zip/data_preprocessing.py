
# data_preprocessing.py

import pandas as pd
import numpy as np

def preprocess_data(file_path):
    data = pd.read_csv(file_path, parse_dates=['Date'], index_col='Date')
    data = data.resample('D').mean()  # Resample to daily frequency
    data = data.fillna(method="ffill")  # Fill missing values
    return data
