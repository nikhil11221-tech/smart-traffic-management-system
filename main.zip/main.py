
# main.py

from src.data_preprocessing import preprocess_data
from src.visualization import plot_traffic_data
from src.model_creation import create_sarima_model, create_prophet_model
from src.evaluation import evaluate_model
import pandas as pd

def main():
    data = preprocess_data('data/traffic_data.csv')
    
    # Plot traffic data
    plot_traffic_data(data)
    
    # Train SARIMA model
    sarima_model = create_sarima_model(data)
    sarima_forecast = sarima_model.predict(start=len(data), end=len(data)+30)
    
    # Train Prophet model
    prophet_model = create_prophet_model(data)
    future = prophet_model.make_future_dataframe(periods=30)
    prophet_forecast = prophet_model.predict(future)['yhat'][-30:]
    
    # Evaluate models
    sarima_eval = evaluate_model(data[-30:], sarima_forecast)
    prophet_eval = evaluate_model(data[-30:], prophet_forecast)

    print("SARIMA Evaluation:", sarima_eval)
    print("Prophet Evaluation:", prophet_eval)

if __name__ == "__main__":
    main()
